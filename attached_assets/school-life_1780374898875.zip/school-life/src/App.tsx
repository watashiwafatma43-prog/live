import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ProgressProvider } from "@/context/ProgressContext";
import BadgeToast from "@/components/BadgeToast";
import Navbar from "@/components/Navbar";
import BottomNav from "@/components/BottomNav";
import Home from "@/pages/Home";
import GradePage from "@/pages/GradePage";
import QuizPage from "@/pages/QuizPage";
import GamePage from "@/pages/GamePage";
import AchievementsPage from "@/pages/AchievementsPage";
import LessonsPage from "@/pages/LessonsPage";
import TrueFalsePage from "@/pages/TrueFalsePage";
import PersonalityGamePage from "@/pages/PersonalityGamePage";
import CompletionPage from "@/pages/CompletionPage";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <>
      <Navbar />
      <BadgeToast />
      <div className="pb-20 sm:pb-0">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/grade/4">{() => <GradePage gradeId={4} />}</Route>
          <Route path="/grade/5">{() => <GradePage gradeId={5} />}</Route>
          <Route path="/grade/6">{() => <GradePage gradeId={6} />}</Route>
          <Route path="/quiz/4">{() => <QuizPage gradeId={4} />}</Route>
          <Route path="/quiz/5">{() => <QuizPage gradeId={5} />}</Route>
          <Route path="/quiz/6">{() => <QuizPage gradeId={6} />}</Route>
          <Route path="/game/4">{() => <GamePage gradeId={4} />}</Route>
          <Route path="/game/5">{() => <GamePage gradeId={5} />}</Route>
          <Route path="/game/6">{() => <GamePage gradeId={6} />}</Route>
          <Route path="/truefalse/4">
            {() => <TrueFalsePage gradeId={4} />}
          </Route>
          <Route path="/truefalse/5">
            {() => <TrueFalsePage gradeId={5} />}
          </Route>
          <Route path="/truefalse/6">
            {() => <TrueFalsePage gradeId={6} />}
          </Route>
          <Route path="/personality" component={PersonalityGamePage} />
          <Route path="/completion" component={CompletionPage} />
          <Route path="/achievements" component={AchievementsPage} />
          <Route path="/lessons" component={LessonsPage} />
          <Route component={NotFound} />
        </Switch>
      </div>
      <BottomNav />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base="">
          <ProgressProvider>
            <Router />
          </ProgressProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
