/* ══════════════════════════════════════════════════════════════
   CORD PHYSICS
══════════════════════════════════════════════════════════════ */
const ROOT = document.documentElement;
const cord = document.getElementById('js-cord');
const hit = document.getElementById('js-hit');
const lampEl = document.querySelector('.lamp');
const nextBtn = document.getElementById('nextBtn');
const mainScene = document.getElementById('mainScene');

const AX = 124, AY = 190;
const REST_X = 124, REST_Y = 348;
const TRIGGER_DIST = 55;

let dragging = false, animating = false, lightOn = false;
let curX = REST_X, curY = REST_Y, clicked = false;

function toSVG(sx, sy) {
    const pt = lampEl.createSVGPoint();
    pt.x = sx; pt.y = sy;
    return pt.matrixTransform(lampEl.getScreenCTM().inverse());
}

function buildCord(tx, ty) {
    const dx = tx - AX, dy = ty - AY;
    const sag = Math.max(4, 30 - Math.hypot(dx, dy) * 0.06);
    const c1x = AX + dx * 0.15 + sag, c1y = AY + dy * 0.30 + sag;
    const c2x = AX + dx * 0.70 - sag * 0.3, c2y = AY + dy * 0.72 - sag * 0.2;
    return `M${AX},${AY} C${c1x},${c1y} ${c2x},${c2y} ${tx},${ty}`;
}

function updateCord(tx, ty) {
    curX = tx; curY = ty;
    cord.setAttribute('d', buildCord(tx, ty));
    const tension = Math.min(Math.hypot(tx - REST_X, ty - REST_Y) / 120, 1);
    cord.style.stroke = `hsl(45, 0%, ${Math.round(38 + tension * 52)}%)`;
}

function springBack(fromX, fromY, triggered) {
    if (animating) return;
    animating = true;
    const dur = triggered ? 380 : 500;
    const t0 = performance.now();
    function tick(now) {
        const t = Math.min((now - t0) / dur, 1);
        const fn = triggered ? easeElastic(t) : easeOutBounce(t);
        updateCord(fromX + (REST_X - fromX) * fn, fromY + (REST_Y - fromY) * fn);
        if (t < 1) { requestAnimationFrame(tick); return; }
        updateCord(REST_X, REST_Y);
        cord.style.stroke = '';
        animating = false;
    }
    requestAnimationFrame(tick);
}

function easeElastic(t) {
    if (!t || t === 1) return t;
    return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1;
}
function easeOutBounce(t) {
    if (t < 1/2.75) return 7.5625*t*t;
    if (t < 2/2.75) { t -= 1.5/2.75; return 7.5625*t*t + 0.750; }
    if (t < 2.5/2.75) { t -= 2.25/2.75; return 7.5625*t*t + 0.9375; }
    t -= 2.625/2.75; return 7.5625*t*t + 0.984375;
}

function client(e) {
    return e.touches ? { x: e.touches[0].clientX, y: e.touches[0].clientY } : { x: e.clientX, y: e.clientY };
}

function onDown(e) { if (animating || clicked) return; e.preventDefault(); dragging = true; }
function onMove(e) {
    if (!dragging) return; e.preventDefault();
    const { x, y } = client(e);
    const sv = toSVG(x, y);
    updateCord(sv.x, Math.max(AY + 20, sv.y));
}
function onUp() {
    if (!dragging) return; dragging = false;
    const dist = Math.hypot(curX - REST_X, curY - REST_Y);
    if (dist > TRIGGER_DIST) toggleLight();
    springBack(curX, curY, dist > TRIGGER_DIST);
}

[hit, cord].forEach(el => {
    el.addEventListener('mousedown', onDown);
    el.addEventListener('touchstart', onDown, { passive: false });
});
window.addEventListener('mousemove', onMove);
window.addEventListener('mouseup', onUp);
window.addEventListener('touchmove', onMove, { passive: false });
window.addEventListener('touchend', onUp);

function toggleLight() {
    lightOn = !lightOn;
    ROOT.style.setProperty('--on', lightOn ? '1' : '0');
    if (lightOn) nextBtn.classList.add('show');
}

nextBtn.addEventListener('click', () => {
    clicked = true;
    nextBtn.classList.remove('show');
    mainScene.classList.add('changed');
});